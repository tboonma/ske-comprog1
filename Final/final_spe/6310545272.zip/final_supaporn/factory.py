class Factory:
    def __init__(self, stock_list, item_list, customer_list):
        self.__stock_list = stock_list
        self.__item_list = item_list
        self.__customer_list = customer_list
    